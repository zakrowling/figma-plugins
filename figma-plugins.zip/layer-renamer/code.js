// This file runs in the Figma 'main' process
// It handles the logic for finding and renaming layers

figma.showUI(__html__, { width: 320, height: 420, title: 'Type Renamer' });

figma.ui.onmessage = (msg) => {
  if (msg.type === 'rename-layers') {
    const { template, includeType, scope } = msg;

    // 1. Determine which layers to process
    let layersToRename = [];
    if (scope === 'selection') {
      layersToRename = figma.currentPage.selection;
    } else {
      // Find all layers on the page, excluding Page/Document nodes
      layersToRename = figma.currentPage.findAll(node => 
        node.type !== 'PAGE' && node.type !== 'DOCUMENT'
      );
    }

    if (layersToRename.length === 0) {
      figma.ui.postMessage({ type: 'error', message: 'No layers found to rename.' });
      return;
    }

    // 2. Group layers by their type (e.g., "RECTANGLE", "FRAME")
    const groupedLayers = {};
    
    layersToRename.forEach(node => {
      // Skip invisible layers if you prefer, or keep them. 
      // Here we rename everything selected/found.
      const typeKey = node.type;
      
      if (!groupedLayers[typeKey]) {
        groupedLayers[typeKey] = [];
      }
      groupedLayers[typeKey].push(node);
    });

    let totalRenamed = 0;

    // 3. Iterate and Rename
    for (const type in groupedLayers) {
      const layers = groupedLayers[type];
      
      // Sort layers by their position (y, then x) so numbering follows visual order
      // Optional: Remove this sort if you prefer layer list order
      layers.sort((a, b) => {
        if (Math.abs(a.y - b.y) > 1) return a.y - b.y;
        return a.x - b.x;
      });

      layers.forEach((node, index) => {
        // Convert 'RECTANGLE' to 'Rectangle'
        const friendlyType = type
          .toLowerCase()
          .replace(/_/g, ' ')
          .replace(/\b\w/g, c => c.toUpperCase());

        // Replace placeholders in the template
        let newName = template
          .replace(/{TYPE}/g, friendlyType)
          .replace(/{INDEX}/g, index + 1);

        // Prepend type if requested
        if (includeType) {
          newName = `${friendlyType} - ${newName}`;
        }

        // Clean up whitespace
        node.name = newName.trim();
        totalRenamed++;
      });
    }

    // 4. Notify UI that we are done
    figma.ui.postMessage({ type: 'rename-complete', count: totalRenamed });
  }
};