import React, { useState, useEffect } from 'react';
import * as ReactDOM from 'react-dom';

// --- MAIN PLUGIN CODE (Runs in Figma's main process) ---
if (typeof figma !== 'undefined') {
  figma.showUI(__html__, { width: 320, height: 380, title: 'Type Renamer' });

  // Listens for messages from the React UI
  figma.ui.onmessage = (msg) => {
    if (msg.type === 'rename-layers') {
      const { template, includeType, scope } = msg;

      const layersToRename = scope === 'selection' && figma.currentPage.selection.length > 0
        ? figma.currentPage.selection
        : figma.currentPage.findAll(node => !['PAGE', 'DOCUMENT'].includes(node.type));

      // Group layers by type
      const groupedLayers: { [key: string]: SceneNode[] } = {};
      layersToRename.forEach(node => {
        // Skip hidden nodes or non-renamable nodes for cleaner output
        if ('visible' in node && !node.visible) return;
        if (node.type === 'PAGE' || node.type === 'DOCUMENT') return;

        const typeKey = node.type;
        if (!groupedLayers[typeKey]) {
          groupedLayers[typeKey] = [];
        }
        groupedLayers[typeKey].push(node);
      });

      let totalRenamed = 0;

      // Iterate through each group and rename
      for (const type in groupedLayers) {
        const layers = groupedLayers[type];
        layers.forEach((node, index) => {
          if ('name' in node) {
            const typeName = type.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase());

            // Build the new name using the template
            let newName = template
              .replace(/\{TYPE\}/g, typeName)
              .replace(/\{INDEX\}/g, (index + 1).toString());

            // If the user checked "Include Type", prepend it for clarity
            if (includeType) {
              newName = `${typeName} - ${newName}`;
            }

            node.name = newName.trim().replace(/\s+/g, ' ');
            totalRenamed++;
          }
        });
      }

      figma.ui.postMessage({ type: 'rename-complete', count: totalRenamed });
    }
  };
}

// --- REACT UI CODE (Runs in the sandboxed iframe) ---

/**
 * Maps Figma's technical layer type to a user-friendly suggestion.
 */
const defaultTemplates: { [key: string]: string } = {
  RECTANGLE: "Background",
  TEXT: "Label",
  FRAME: "Group",
  COMPONENT: "Instance",
  GROUP: "Section",
  VECTOR: "Icon/Shape"
};

const App = () => {
  const [template, setTemplate] = useState('Layer {INDEX}');
  const [includeType, setIncludeType] = useState(true);
  const [scope, setScope] = useState<'selection' | 'all'>('selection');
  const [status, setStatus] = useState('');

  // Handle messages from the main plugin code
  useEffect(() => {
    window.onmessage = (event) => {
      const msg = event.data.pluginMessage;
      if (msg.type === 'rename-complete') {
        setStatus(`✅ Renamed ${msg.count} layers!`);
        setTimeout(() => setStatus(''), 3000);
      }
    };
  }, []);

  const handleRename = () => {
    setStatus('Renaming...');
    // Send message to the main plugin code
    parent.postMessage({
      pluginMessage: {
        type: 'rename-layers',
        template,
        includeType,
        scope
      }
    }, '*');
  };

  const setPresetTemplate = (preset: string) => {
    setTemplate(preset);
  };

  return (
    <div className="p-4 space-y-4 font-sans bg-gray-50 h-full">
      <h1 className="text-xl font-bold text-gray-800">Layer Type Renamer</h1>

      <div className="space-y-3">
        {/* Scope Selection */}
        <div className="flex items-center space-x-4 p-2 bg-white rounded-lg shadow-sm">
          <label className="flex items-center text-sm font-medium text-gray-700">
            <input
              type="radio"
              name="scope"
              value="selection"
              checked={scope === 'selection'}
              onChange={() => setScope('selection')}
              className="form-radio text-indigo-600 h-4 w-4"
            />
            <span className="ml-2">Selection</span>
          </label>
          <label className="flex items-center text-sm font-medium text-gray-700">
            <input
              type="radio"
              name="scope"
              value="all"
              checked={scope === 'all'}
              onChange={() => setScope('all')}
              className="form-radio text-indigo-600 h-4 w-4"
            />
            <span className="ml-2">All Layers</span>
          </label>
        </div>

        {/* Template Input */}
        <div>
          <label htmlFor="template" className="block text-sm font-medium text-gray-700 mb-1">
            Rename Template:
          </label>
          <input
            id="template"
            type="text"
            value={template}
            onChange={(e) => setTemplate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm"
            placeholder="e.g., Background {INDEX}"
          />
        </div>

        {/* Template Variables */}
        <div className="text-xs text-gray-500">
          Use variables: <code className="bg-indigo-100 text-indigo-800 p-0.5 rounded">{'{}'}TYPE</code>, <code className="bg-indigo-100 text-indigo-800 p-0.5 rounded">{'{}'}INDEX</code>
        </div>

        {/* Options */}
        <div className="flex items-center">
          <input
            id="includeType"
            type="checkbox"
            checked={includeType}
            onChange={(e) => setIncludeType(e.target.checked)}
            className="h-4 w-4 text-indigo-600 border-gray-300 rounded"
          />
          <label htmlFor="includeType" className="ml-2 block text-sm text-gray-900">
            Prepend Type (e.g., "RECTANGLE - ...")
          </label>
        </div>

        {/* Quick Presets */}
        <div className="pt-2">
          <p className="text-sm font-medium text-gray-700 mb-1">Quick Presets:</p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(defaultTemplates).map(([type, name]) => (
              <button
                key={type}
                onClick={() => setPresetTemplate(name)}
                className="px-3 py-1 text-xs font-medium text-indigo-700 bg-indigo-100 rounded-full hover:bg-indigo-200 transition duration-150"
              >
                {name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Status and Execute Button */}
      <div className="pt-4 border-t border-gray-200">
        <button
          onClick={handleRename}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-lg shadow-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150"
        >
          {scope === 'selection' ? 'Rename Selected Layers' : 'Rename All Layers'}
        </button>
        {status && (
          <p className={`mt-2 text-center text-sm font-semibold ${status.startsWith('✅') ? 'text-green-600' : 'text-indigo-600'}`}>
            {status}
          </p>
        )}
      </div>

      {/* Tailwind CSS included for styling (assuming Tailwind is available or loaded) */}
      <script src="https://cdn.tailwindcss.com"></script>
    </div>
  );
};

// Render the React app into the UI root element
if (typeof figma === 'undefined') {
  ReactDOM.render(<App />, document.getElementById('react-page'));
}

// Add the HTML structure for the React app to attach to
if (typeof figma === 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    const root = document.createElement('div');
    root.id = 'react-page';
    document.body.appendChild(root);
    ReactDOM.render(<App />, root);
  });
}