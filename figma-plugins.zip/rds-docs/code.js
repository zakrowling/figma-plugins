// NOTE ON ERRORS: If you see errors like 'Syntax error: Unexpected token ?',
// it means your Figma environment does not support ES2020 features like optional chaining (?. ).
// This version removes all optional chaining syntax to maximize compatibility.

// The uploaded component list content is hardcoded here for simplicity,
// as the plugin cannot read external files directly at runtime.
const componentListRaw = `
Alert - https://rhythm.bupa.com.au/00664bfdd/p/61b02c-alert
Input - https://rhythm.bupa.com.au/00664bfdd/p/271d04-inputs
Checkbox - https://rhythm.bupa.com.au/00664bfdd/p/36dcf8-checkbox
Radio - https://rhythm.bupa.com.au/00664bfdd/p/55e4f9-radio
Text - https://rhythm.bupa.com.au/00664bfdd/p/6885f4-text-field
Select - https://rhythm.bupa.com.au/00664bfdd/p/390037-select
Textarea - https://rhythm.bupa.com.au/00664bfdd/p/43ec0f-text-area
Picker Group - https://rhythm.bupa.com.au/00664bfdd/p/040e15-picker-group
Combobox - https://rhythm.bupa.com.au/00664bfdd/p/67ec2a-combobox
Datepicker - https://rhythm.bupa.com.au/00664bfdd/p/204e13-date-picker
Navigation - https://rhythm.bupa.com.au/00664bfdd/p/85bf85-navigation
Back To Top - https://rhythm.bupa.com.au/00664bfdd/p/42781d-back-to-top
Breadcrumb - https://rhythm.bupa.com.au/00664bfdd/p/329901-breadcrumb
Button - https://rhythm.bupa.com.au/00664bfdd/p/234a14-buttons
Button Bar - https://rhythm.bupa.com.au/00664bfdd/p/723ed0-button-bar
Icon Button - https://rhythm.bupa.com.au/00664bfdd/p/39ecad-icon-button
Chip - https://rhythm.bupa.com.au/00664bfdd/p/903c2a-chip
Loading Button - https://rhythm.bupa.com.au/00664bfdd/p/627938-loading-button
Link - https://rhythm.bupa.com.au/00664bfdd/p/3171f1-link
Tab - https://rhythm.bupa.com.au/00664bfdd/p/06e7fa-tabs
Accordion - https://rhythm.bupa.com.au/00664bfdd/p/86fd75-accordion
Avatar - https://rhythm.bupa.com.au/00664bfdd/p/59def7-avatar
Backdrop - https://rhythm.bupa.com.au/00664bfdd/p/36f6c5-backdrop
Badge - https://rhythm.bupa.com.au/00664bfdd/p/0218df-badge
Divider - https://rhythm.bupa.com.au/00664bfdd/p/208c0b-divider
Disclosure - https://rhythm.bupa.com.au/00664bfdd/p/61a704-disclosure
Drawer - https://rhythm.bupa.com.au/00664bfdd/p/35f668-drawer
Image - https://rhythm.bupa.com.au/00664bfdd/p/945432-image
Heading - https://rhythm.bupa.com.au/00664bfdd/p/4206fb-heading
Hero Banner - https://rhythm.bupa.com.au/00664bfdd/p/299c7b-hero-banner
List - https://rhythm.bupa.com.au/00664bfdd/p/1279ac-list
Loading Screen - https://rhythm.bupa.com.au/00664bfdd/p/706124-loading-screen
Media - https://rhythm.bupa.com.au/00664bfdd/p/47d9e6-media
Modal - https://rhythm.bupa.com.au/00664bfdd/p/375d66-modal
Pictogram - https://rhythm.bupa.com.au/00664bfdd/p/09ce2d-pictogram--system-icon
Rich Text Content - https://rhythm.bupa.com.au/00664bfdd/p/612868-rich-text-content
Single Feature - https://rhythm.bupa.com.au/00664bfdd/p/89938b-single-feature
Spinner - https://rhythm.bupa.com.au/00664bfdd/p/68e4de-spinner
SVG Icon - https://rhythm.bupa.com.au/00664bfdd/p/78080c-svg-icon
Table - https://rhythm.bupa.com.au/00664bfdd/p/43c6e8-table
Text - https://rhythm.bupa.com.au/00664bfdd/p/6072c9-text
Time To Read - https://rhythm.bupa.com.au/00664bfdd/p/69c8fd-time-to-read
Toggletip - https://rhythm.bupa.com.au/00664bfdd/p/6535fe-toggletip
Tooltip - https://rhythm.bupa.com.au/00664bfdd/p/185de0-tooltip
`;

/**
 * This code is pure JavaScript (ES5/ES6 compliant) and does not use optional chaining (?. ) or other modern, unsupported syntax.
 */

// 1. Parse the raw component list into a map
function parseComponentList(rawText) {
  const docs = {};
  const lines = rawText.trim().split('\n');

  lines.forEach(line => {
    // Find the first occurrence of " - " to separate name and URL
    const separatorIndex = line.indexOf(' - ');
    if (separatorIndex > -1) {
      const name = line.substring(0, separatorIndex).trim();
      const url = line.substring(separatorIndex + 3).trim();
      if (name && url) {
        // Use an uppercase version of the name as the key for case-insensitive lookup later
        docs[name.toUpperCase()] = url;
      }
    }
  });

  return docs;
}

// Global variable to hold the parsed documentation map
const componentDocs = parseComponentList(componentListRaw);

/**
 * Checks the current selection and posts the relevant documentation URL to the UI.
 * This function runs on plugin start and every time the selection changes.
 */
function checkSelection() {
  // Use a try/catch block to catch errors during selection processing
  try {
    // Defensive check: Ensure figma.currentPage exists before accessing it
    if (!figma.currentPage) {
        console.error("Figma API error: figma.currentPage is undefined.");
        figma.ui.postMessage({ type: 'error', message: 'Figma context error. Please refresh plugin.' });
        return;
    }
    
    const selection = figma.currentPage.selection;
    let match = null;

    if (selection.length === 1) {
      const node = selection[0];
      
      // We only care about Instances and Main Components
      if (node.type === "INSTANCE" || node.type === "COMPONENT") {
        const componentName = node.name.toUpperCase();
        let docUrl = null;
        
        // Iterate through the documentation keys to find a match 
        // where the Figma node name INCLUDES the documentation component name.
        for (const docName in componentDocs) {
          if (componentName.includes(docName)) {
            docUrl = componentDocs[docName];
            // We break immediately to ensure we match the most specific component name if present.
            break; 
          }
        }

        match = {
          name: node.name,
          url: docUrl,
          id: node.id,
          type: node.type,
        };
      }
    }

    // If no match was found (or nothing selected)
    if (!match) {
        const selectedNode = selection.length > 0 ? selection[0] : null;
        
        // CRITICAL FIX: Replaced 'selectedNode?.name' and 'selectedNode?.type' with ternary operator 
        // for backward compatibility to avoid the Syntax Error.
        var nodeName = selectedNode ? selectedNode.name : 'No Node Selected';
        var nodeType = selectedNode ? selectedNode.type : 'None';

        match = {
            name: nodeName,
            url: null,
            id: selectedNode ? selectedNode.id : 'none',
            type: nodeType,
        };
    }

    // Send the result to the UI
    figma.ui.postMessage({ type: 'selected-component', data: match });
  } catch (e) {
    // Log the error and notify the user via the console/UI, but don't close the plugin
    console.error("Error during selection check:", e);
    figma.ui.postMessage({ 
        type: 'error', 
        message: 'An internal error occurred during selection processing. Check console.' 
    });
  }
}

// Main execution flow
try {
  // Ensure the UI is shown correctly. __html__ is provided by the runner environment.
  // Updated size to half of 800x600 -> 400x300
  figma.showUI(__html__, { width: 400, height: 300, title: "RDS Component Documentation" });

  // 1. Check the initial selection when the plugin is opened
  checkSelection();

  // 2. Set up the event listener to check every time the selection changes
  // Check if figma.on is available before subscribing (defense against environment issues)
  if (figma.on) {
    figma.on('selectionchange', checkSelection);
  } else {
    console.warn("Figma API warning: figma.on is not available.");
  }

  // Handler for messages from the UI
  figma.ui.onmessage = msg => {
    // Handle opening a URL externally
    if (msg.type === 'open-url' && msg.url) {
        if (figma.openExternal) {
             figma.openExternal(msg.url);
        } else {
             console.error("Figma API error: figma.openExternal is not available.");
        }
    }
    
    // Handle jumping to a node (fallback/utility)
    if (msg.type === 'jump-to-node' && msg.id) {
      const node = figma.getNodeById(msg.id);
      if (node && figma.currentPage && figma.viewport) {
        figma.currentPage.selection = [node];
        figma.viewport.scrollAndZoomIntoView([node]);
      }
    }
    
    // Check if the user closed the plugin via the UI (not typically used, but good practice)
    if (msg.type === 'close') {
        figma.closePlugin();
    }
  };
} catch (error) {
  // Final, severe error logging and plugin closing
  console.error("Plugin startup failed during main execution:", error);
  // Close the plugin with a message to give the user a hint in the UI
  figma.closePlugin(`CRITICAL STARTUP FAILURE: ${error.message || 'Unknown. Check console for details.'}`);
}